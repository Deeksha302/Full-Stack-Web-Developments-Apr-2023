x=0o125
print(bin(x))
