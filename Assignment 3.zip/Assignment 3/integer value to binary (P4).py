x=12
print(bin(x))