x=0x2F
print(oct(x))