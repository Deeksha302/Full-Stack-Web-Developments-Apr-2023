# first method
x=0o25
y=0x39
s=x+y
print(bin(x)+bin(y))

"""# second method
print(bin(0o25) + bin(0x39))"""

