x=100
print(chr(x))