x='m'
print(ord(x))