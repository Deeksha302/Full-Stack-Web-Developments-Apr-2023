x=0b1100101
print(x)