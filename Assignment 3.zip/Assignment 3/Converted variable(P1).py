x=60
print(type(str(x)))