x=12
print(hex(x))
