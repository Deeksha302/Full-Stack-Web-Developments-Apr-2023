x=12
print(oct(x))