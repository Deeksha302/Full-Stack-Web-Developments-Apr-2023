x=int(input("enter your first number:"))
y=int(input("enter your second number:"))
sum=x+y
print(sum)