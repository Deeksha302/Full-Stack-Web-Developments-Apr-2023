x=int(input("enter your number"))
print(x)