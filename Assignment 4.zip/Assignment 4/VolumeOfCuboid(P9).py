l=int(input("enter a length"))
b=int(input("enter a breadth"))
h=int(input("enter a height"))
VolumeCuboid=l*b*h
print(VolumeCuboid)