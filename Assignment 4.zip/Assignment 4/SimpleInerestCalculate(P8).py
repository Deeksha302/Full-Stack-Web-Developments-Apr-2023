p=int(input("enter a Principle number"))
r=float(input("enter a Rate of interest"))
t=int(input("enter a Time in year"))
si=p*r*t/100
print(si)