x=input("enter your name:")
print(x)