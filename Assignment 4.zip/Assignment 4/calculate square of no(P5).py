a=int(input("enter a number"))
s=4*a
print(s)