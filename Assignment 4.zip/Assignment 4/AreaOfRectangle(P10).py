l=int(input("ente a length"))
w=int(input("enter a width"))
A=l*w
print(A)