a=10
b=20
c=30
print(a,b,c,sep='\n')
# not used sep
a=10
b=20
c=30
print(a)
print(b)
