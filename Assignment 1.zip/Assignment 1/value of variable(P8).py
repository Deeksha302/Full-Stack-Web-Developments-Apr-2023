x="Deeksha"
print(x)