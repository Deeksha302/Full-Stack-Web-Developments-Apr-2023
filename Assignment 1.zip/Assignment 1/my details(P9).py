a="Dimple Lamba"
b=22
c="B.tech"
d="3 year experience"
print(a,b,c,d,sep='\n')