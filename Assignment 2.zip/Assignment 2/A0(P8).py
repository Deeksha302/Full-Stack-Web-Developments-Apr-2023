import A1
print(A1.x)
