a='True','False','None'
print(a)
print(type(a))
# These keyword is used as data in the python,this called soft keyword
