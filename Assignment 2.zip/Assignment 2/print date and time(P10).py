from datetime import datetime
dt=datetime.today()
print(dt)

# x,y d,h,,m,s format date and time
d1=dt.strftime("%d-%m-%Y and %I:%M:%p")
print(d1)


# %B complete month name print karne ke liye and capital Y ka used hum 2023 ko pura print krne ke liye krege
d1=dt.strftime("%B %d %Y")
print(d1)

# %b short month name print karne ke liye and capital Y ka used hum 2023 ko pura print krne ke liye krege
d1=dt.strftime("%d/%b/%Y")
print(d1)

# %H-hour and %M-minutes and %S-second and then %p is used AM and PM ke liye used hota hai
d1=dt.strftime("%H:%M:%S %p")
print(d1)

# short date print krne ke liye
d1=dt.strftime("%d-%m-%y")
print(d1)