a=35
b='True'
c="MySirG"
d=4.5
e=3+4j
print(type(a))    #int 
print(type(b))     #bool
print(type(c))     #str
print(type(d))      #float
print(type(e))       #complex