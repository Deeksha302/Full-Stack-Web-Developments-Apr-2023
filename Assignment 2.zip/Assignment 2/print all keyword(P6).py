import keyword
print(keyword.kwlist)
#False and True and None is soft keyword as a data used 