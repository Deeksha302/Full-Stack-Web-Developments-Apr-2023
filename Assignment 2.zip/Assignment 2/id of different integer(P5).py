a=20
b=6.4
print(type(a))
print(type(b))
print(id(a))
print(id(b))
# different id  of integer variable and type 