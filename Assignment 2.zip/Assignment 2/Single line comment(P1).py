# writ python a script to add comment and print "learning python" on the screen
print("\"Learing python\"")