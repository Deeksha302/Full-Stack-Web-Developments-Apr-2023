a=20
b=20
print(id(a))
print(id(b))
# id python mai address ko bolte hai