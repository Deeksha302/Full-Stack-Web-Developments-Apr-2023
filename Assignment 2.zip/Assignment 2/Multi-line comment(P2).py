'''This is 
multi line comment 
and for variable print in new line 
conatins any values
'''
a=10
b=20
c=30
d=40
print(a,b,c,d,sep='\n')